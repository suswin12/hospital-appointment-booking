const mongoose = require("mongoose");
const dotenv = require("dotenv");
const Doctor = require("./models/doctor");

dotenv.config();

const doctors = [
  {
    name: "Dr. Ajay Kumar",
    specialization: "Cardiologist",
    availableSlots: [
      { date: "2026-04-12", time: "09:00 AM" },
      { date: "2026-04-12", time: "11:00 AM" }
    ]
  },
  {
    name: "Dr. Nivetha Raj",
    specialization: "Dermatologist",
    availableSlots: [
      { date: "2026-04-12", time: "10:00 AM" },
      { date: "2026-04-12", time: "01:00 PM" }
    ]
  },
  {
    name: "Dr. Harish Balan",
    specialization: "Orthopedic",
    availableSlots: [
      { date: "2026-04-12", time: "09:30 AM" },
      { date: "2026-04-12", time: "03:00 PM" }
    ]
  },
  {
    name: "Dr. Meera Lakshmi",
    specialization: "Pediatrician",
    availableSlots: [
      { date: "2026-04-12", time: "10:30 AM" },
      { date: "2026-04-12", time: "12:30 PM" }
    ]
  },
  {
    name: "Dr. Saravanan V",
    specialization: "Neurologist",
    availableSlots: [
      { date: "2026-04-12", time: "08:30 AM" },
      { date: "2026-04-12", time: "02:30 PM" }
    ]
  },
  {
    name: "Dr. Kavitha S",
    specialization: "Gynecologist",
    availableSlots: [
      { date: "2026-04-12", time: "11:00 AM" },
      { date: "2026-04-12", time: "04:00 PM" }
    ]
  },
  {
    name: "Dr. Naveen Chandran",
    specialization: "ENT Specialist",
    availableSlots: [
      { date: "2026-04-12", time: "09:15 AM" },
      { date: "2026-04-12", time: "01:45 PM" }
    ]
  },
  {
    name: "Dr. Divya Narayan",
    specialization: "Psychiatrist",
    availableSlots: [
      { date: "2026-04-12", time: "10:45 AM" },
      { date: "2026-04-12", time: "05:00 PM" }
    ]
  },
  {
    name: "Dr. Pradeep Raman",
    specialization: "General Physician",
    availableSlots: [
      { date: "2026-04-12", time: "08:00 AM" },
      { date: "2026-04-12", time: "12:00 PM" }
    ]
  },
  {
    name: "Dr. Swetha Anand",
    specialization: "Ophthalmologist",
    availableSlots: [
      { date: "2026-04-12", time: "09:45 AM" },
      { date: "2026-04-12", time: "03:30 PM" }
    ]
  },
  {
    name: "Dr. Rohit Menon",
    specialization: "Urologist",
    availableSlots: [
      { date: "2026-04-12", time: "10:15 AM" },
      { date: "2026-04-12", time: "02:15 PM" }
    ]
  },
  {
    name: "Dr. Aishwarya Devi",
    specialization: "Oncologist",
    availableSlots: [
      { date: "2026-04-12", time: "11:15 AM" },
      { date: "2026-04-12", time: "04:30 PM" }
    ]
  },
  {
    name: "Dr. Karthik Raj",
    specialization: "Nephrologist",
    availableSlots: [
      { date: "2026-04-12", time: "08:45 AM" },
      { date: "2026-04-12", time: "01:15 PM" }
    ]
  },
  {
    name: "Dr. Farzana Ali",
    specialization: "Pulmonologist",
    availableSlots: [
      { date: "2026-04-12", time: "09:50 AM" },
      { date: "2026-04-12", time: "03:50 PM" }
    ]
  },
  {
    name: "Dr. Vignesh Kumar",
    specialization: "Gastroenterologist",
    availableSlots: [
      { date: "2026-04-12", time: "10:20 AM" },
      { date: "2026-04-12", time: "02:40 PM" }
    ]
  },
  {
    name: "Dr. Janani Priya",
    specialization: "Endocrinologist",
    availableSlots: [
      { date: "2026-04-12", time: "09:10 AM" },
      { date: "2026-04-12", time: "12:50 PM" }
    ]
  },
  {
    name: "Dr. Aravind S",
    specialization: "Rheumatologist",
    availableSlots: [
      { date: "2026-04-12", time: "11:40 AM" },
      { date: "2026-04-12", time: "04:10 PM" }
    ]
  },
  {
    name: "Dr. Keerthana M",
    specialization: "Radiologist",
    availableSlots: [
      { date: "2026-04-12", time: "08:20 AM" },
      { date: "2026-04-12", time: "01:30 PM" }
    ]
  },
  {
    name: "Dr. Abdul Rahman",
    specialization: "Dentist",
    availableSlots: [
      { date: "2026-04-12", time: "10:10 AM" },
      { date: "2026-04-12", time: "03:10 PM" }
    ]
  },
  {
    name: "Dr. Monica Joseph",
    specialization: "Anesthesiologist",
    availableSlots: [
      { date: "2026-04-12", time: "09:35 AM" },
      { date: "2026-04-12", time: "02:55 PM" }
    ]
  }
];

const seedDoctors = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected");

    await Doctor.deleteMany({});
    await Doctor.insertMany(doctors);
    console.log("20 doctors inserted successfully");

    process.exit();
  } catch (error) {
    console.error("Error inserting doctors:", error);
    process.exit(1);
  }
};

seedDoctors();