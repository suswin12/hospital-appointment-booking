const Doctor = require("../models/doctor");

// Add Doctor (Admin)
exports.addDoctor = async (req, res) => {
  try {
    const { name, specialization, availableSlots } = req.body;

    const doctor = await Doctor.create({
      name,
      specialization,
      availableSlots,
    });

    res.status(201).json({
      message: "Doctor added",
      doctor,
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all doctors
exports.getDoctors = async (req, res) => {
  try {
    const doctors = await Doctor.find();
    res.json(doctors);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};