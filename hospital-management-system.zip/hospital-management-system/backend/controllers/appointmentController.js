const Appointment = require("../models/Appointment");

// Book appointment
exports.bookAppointment = async (req, res) => {
  try {
    const {
      patientId,
      doctorId,
      patientName,
      email,
      phone,
      department,
      reason,
      date,
      time,
    } = req.body;

    if (
      !patientId ||
      !doctorId ||
      !patientName ||
      !email ||
      !phone ||
      !department ||
      !date ||
      !time
    ) {
      return res.status(400).json({
        message: "Please fill all required appointment fields",
      });
    }

    const appointment = await Appointment.create({
      patientId,
      doctorId,
      patientName,
      email,
      phone,
      department,
      reason,
      date,
      time,
    });

    res.status(201).json({
      message: "Appointment booked successfully",
      appointment,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all appointments
exports.getAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate("patientId", "name email")
      .populate("doctorId", "name specialization")
      .sort({ createdAt: -1 });

    res.json(appointments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};