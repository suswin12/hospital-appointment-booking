import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import {
  Calendar,
  Clock3,
  HeartPulse,
  Home,
  Mail,
  Menu,
  Phone,
  ShieldCheck,
  Stethoscope,
  UserRound,
  X,
} from "lucide-react";
import "./App.css";

const API = "http://localhost:5000";

function App() {
  const [activePage, setActivePage] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);

  const [authForm, setAuthForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [userId, setUserId] = useState("");
  const [authMessage, setAuthMessage] = useState("");

  const [doctors, setDoctors] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loadingDoctors, setLoadingDoctors] = useState(false);

  const [bookingForm, setBookingForm] = useState({
    patientName: "",
    email: "",
    phone: "",
    date: "",
    department: "",
    doctorId: "",
    time: "",
    reason: "",
  });

  const [bookingMessage, setBookingMessage] = useState("");

  const navItems = [
    { id: "home", label: "Home", icon: Home },
    { id: "services", label: "Services", icon: HeartPulse },
    { id: "doctors", label: "Doctors", icon: Stethoscope },
    { id: "appointment", label: "Appointment", icon: Calendar },
    { id: "about", label: "About", icon: ShieldCheck },
    { id: "contact", label: "Contact", icon: Phone },
  ];

  useEffect(() => {
    fetchDoctors();
    fetchAppointments();

    const savedUserId = localStorage.getItem("userId");
    const savedEmail = localStorage.getItem("userEmail");
    const savedName = localStorage.getItem("userName");

    if (savedUserId) {
      setUserId(savedUserId);
    }

    if (savedEmail || savedName) {
      setBookingForm((prev) => ({
        ...prev,
        email: savedEmail || "",
        patientName: savedName || "",
      }));
    }
  }, []);

  useEffect(() => {
    if (doctors.length > 0 && !bookingForm.doctorId) {
      const firstDoctor = doctors[0];
      const firstTime = firstDoctor.availableSlots?.[0]?.time || "";

      setBookingForm((prev) => ({
        ...prev,
        doctorId: firstDoctor._id,
        department: firstDoctor.specialization || "",
        time: firstTime,
      }));
    }
  }, [doctors, bookingForm.doctorId]);

  const selectedDoctor = useMemo(() => {
    return doctors.find((doc) => doc._id === bookingForm.doctorId) || null;
  }, [doctors, bookingForm.doctorId]);

  const availableTimes = useMemo(() => {
    if (!selectedDoctor?.availableSlots) return [];
    return selectedDoctor.availableSlots.map((slot) => slot.time);
  }, [selectedDoctor]);

  const fetchDoctors = async () => {
    try {
      setLoadingDoctors(true);
      const res = await axios.get(`${API}/api/doctors`);
      setDoctors(res.data);
    } catch (err) {
      console.log(err);
    } finally {
      setLoadingDoctors(false);
    }
  };

  const fetchAppointments = async () => {
    try {
      const res = await axios.get(`${API}/api/appointments`);
      setAppointments(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleAuthChange = (e) => {
    const { name, value } = e.target;
    setAuthForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleBookingChange = (e) => {
    const { name, value } = e.target;

    if (name === "doctorId") {
      const chosenDoctor = doctors.find((doc) => doc._id === value);
      const firstTime = chosenDoctor?.availableSlots?.[0]?.time || "";

      setBookingForm((prev) => ({
        ...prev,
        doctorId: value,
        department: chosenDoctor?.specialization || "",
        time: firstTime,
      }));
      return;
    }

    setBookingForm((prev) => ({ ...prev, [name]: value }));
  };

  const registerUser = async () => {
    setAuthMessage("");
    try {
      const res = await axios.post(`${API}/api/auth/register`, authForm);
      setAuthMessage(res.data.message || "User registered successfully");
    } catch (err) {
      setAuthMessage(err.response?.data?.message || "Registration failed");
    }
  };

  const loginUser = async () => {
    setAuthMessage("");
    try {
      const res = await axios.post(`${API}/api/auth/login`, {
        email: authForm.email,
        password: authForm.password,
      });

      const token = res.data.token;
      localStorage.setItem("token", token);

      if (res.data.user?.id) {
        setUserId(res.data.user.id);
        localStorage.setItem("userId", res.data.user.id);
      }

      if (res.data.user?.email) {
        localStorage.setItem("userEmail", res.data.user.email);
      }

      if (res.data.user?.name) {
        localStorage.setItem("userName", res.data.user.name);
      }

      setBookingForm((prev) => ({
        ...prev,
        patientName: res.data.user?.name || prev.patientName,
        email: res.data.user?.email || prev.email,
      }));

      setAuthMessage(`Login successful. Welcome ${res.data.user?.name || ""}`);
    } catch (err) {
      setAuthMessage(err.response?.data?.message || "Login failed");
    }
  };

  const bookAppointment = async (e) => {
    e.preventDefault();
    setBookingMessage("");

    if (!userId) {
      setBookingMessage("Please login before booking an appointment.");
      return;
    }

    if (
      !bookingForm.patientName ||
      !bookingForm.email ||
      !bookingForm.phone ||
      !bookingForm.department ||
      !bookingForm.doctorId ||
      !bookingForm.date ||
      !bookingForm.time
    ) {
      setBookingMessage("Please fill all required fields.");
      return;
    }

    try {
      const payload = {
        patientId: userId,
        doctorId: bookingForm.doctorId,
        patientName: bookingForm.patientName,
        email: bookingForm.email,
        phone: bookingForm.phone,
        department: bookingForm.department,
        reason: bookingForm.reason,
        date: bookingForm.date,
        time: bookingForm.time,
      };

      await axios.post(`${API}/api/appointments`, payload);

      setBookingMessage("Appointment booked successfully.");
      fetchAppointments();

      setBookingForm((prev) => ({
        ...prev,
        phone: "",
        date: "",
        reason: "",
      }));
    } catch (err) {
      console.log(err);
      setBookingMessage(
        err.response?.data?.message || "Error booking appointment"
      );
    }
  };

  const goTo = (page) => {
    setActivePage(page);
    setMenuOpen(false);
  };

  return (
    <div className="app-shell">
      <div className="bg-orb bg-orb-1"></div>
      <div className="bg-orb bg-orb-2"></div>

      <header className="site-header">
        <div className="brand-wrap">
          <div className="brand-icon">
            <HeartPulse size={22} />
          </div>
          <div>
            <h1 className="brand-title">MediCare Plus</h1>
            <p className="brand-subtitle">
              Hospital Appointment & Patient Management
            </p>
          </div>
        </div>

        <nav className="desktop-nav">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className={`nav-btn ${activePage === item.id ? "active" : ""}`}
                onClick={() => goTo(item.id)}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <button
          className="mobile-menu-btn"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      {menuOpen && (
        <div className="mobile-nav">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className="mobile-nav-btn"
                onClick={() => goTo(item.id)}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}
        </div>
      )}

      <main className="main-content">
        {activePage === "home" && (
          <section className="hero-grid">
            <div className="hero-left">
              <div className="badge">
                <ShieldCheck size={16} />
                Smart Healthcare Experience
              </div>

              <h2 className="hero-title">
                Book Your <span>Doctor Appointment</span> with Ease
              </h2>

              <p className="hero-text">
                A complete full-stack hospital website with secure login,
                doctor management, appointment booking, and a responsive
                interface for patients and administrators.
              </p>

              <div className="hero-actions">
                <button className="primary-btn" onClick={() => goTo("appointment")}>
                  Book Appointment
                </button>
                <button className="secondary-btn" onClick={() => goTo("doctors")}>
                  View Doctors
                </button>
              </div>

              <div className="stats-grid">
                <div className="stat-card">
                  <h3>25+</h3>
                  <p>Specialist Doctors</p>
                </div>
                <div className="stat-card">
                  <h3>1000+</h3>
                  <p>Happy Patients</p>
                </div>
                <div className="stat-card">
                  <h3>24/7</h3>
                  <p>Emergency Support</p>
                </div>
              </div>
            </div>

            <div className="hero-right">
              <img
                src="https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&w=1200&q=80"
                alt="hospital"
                className="hero-image"
              />

              <div className="floating-info">
                <div className="mini-card">
                  <UserRound size={18} />
                  <span>Patient Friendly</span>
                </div>
                <div className="mini-card">
                  <Clock3 size={18} />
                  <span>Fast Booking</span>
                </div>
                <div className="mini-card">
                  <Stethoscope size={18} />
                  <span>Expert Doctors</span>
                </div>
              </div>
            </div>
          </section>
        )}

        {activePage === "services" && (
          <section>
            <div className="section-head center">
              <h2>Our Services</h2>
              <p>Everything needed for a smooth hospital appointment experience.</p>
            </div>

            <div className="service-grid">
              {[
                "Online appointment booking",
                "Doctor availability management",
                "Patient registration and login",
                "Appointment tracking and monitoring",
              ].map((item) => (
                <div className="glass-card service-card" key={item}>
                  <div className="service-icon">
                    <HeartPulse size={24} />
                  </div>
                  <h3>{item}</h3>
                  <p>
                    Built for better hospital workflow, faster access, and a
                    user-friendly healthcare interface.
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {activePage === "doctors" && (
          <section>
            <div className="section-head">
              <div>
                <h2>Our Doctors</h2>
                <p>Select a doctor based on specialization and available slots.</p>
              </div>
              <button className="primary-btn" onClick={() => goTo("appointment")}>
                Go to Booking
              </button>
            </div>

            {loadingDoctors ? (
              <div className="glass-card">Loading doctors...</div>
            ) : (
              <div className="doctor-grid">
                {doctors.map((doc) => (
                  <div className="doctor-card" key={doc._id}>
                    <img
                      src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=1000&q=80"
                      alt={doc.name}
                      className="doctor-image"
                    />
                    <div className="doctor-body">
                      <h3>{doc.name}</h3>
                      <p className="doctor-speciality">{doc.specialization}</p>

                      <div className="slot-wrap">
                        {(doc.availableSlots || []).map((slot, index) => (
                          <span className="slot-pill" key={index}>
                            {slot.date} - {slot.time}
                          </span>
                        ))}
                      </div>

                      <button
                        className="primary-btn full-btn"
                        onClick={() => {
                          setBookingForm((prev) => ({
                            ...prev,
                            doctorId: doc._id,
                            department: doc.specialization,
                            time: doc.availableSlots?.[0]?.time || "",
                          }));
                          goTo("appointment");
                        }}
                      >
                        Book Now
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {activePage === "appointment" && (
          <section className="appointment-grid">
            <div className="glass-card appointment-form-card">
              <h2>Book Appointment</h2>
              <p className="subtext">
                Fill in your details and confirm your appointment.
              </p>

              <div className="auth-box">
                <h3>Register / Login</h3>

                <div className="form-grid two-col">
                  <input
                    type="text"
                    name="name"
                    placeholder="Enter name"
                    value={authForm.name}
                    onChange={handleAuthChange}
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Enter email"
                    value={authForm.email}
                    onChange={handleAuthChange}
                  />
                </div>

                <input
                  type="password"
                  name="password"
                  placeholder="Enter password"
                  value={authForm.password}
                  onChange={handleAuthChange}
                />

                <div className="action-row">
                  <button className="primary-btn" type="button" onClick={registerUser}>
                    Register
                  </button>
                  <button className="secondary-btn" type="button" onClick={loginUser}>
                    Login
                  </button>
                </div>

                {authMessage && <div className="inline-message">{authMessage}</div>}
              </div>

              <form className="booking-form" onSubmit={bookAppointment}>
                <div className="form-grid two-col">
                  <input
                    type="text"
                    name="patientName"
                    placeholder="Patient name"
                    value={bookingForm.patientName}
                    onChange={handleBookingChange}
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Patient email"
                    value={bookingForm.email}
                    onChange={handleBookingChange}
                  />
                </div>

                <div className="form-grid two-col">
                  <input
                    type="text"
                    name="phone"
                    placeholder="Phone number"
                    value={bookingForm.phone}
                    onChange={handleBookingChange}
                  />
                  <input
                    type="date"
                    name="date"
                    value={bookingForm.date}
                    onChange={handleBookingChange}
                  />
                </div>

                <div className="form-grid two-col">
                  <select
                    name="doctorId"
                    value={bookingForm.doctorId}
                    onChange={handleBookingChange}
                  >
                    {doctors.map((doc) => (
                      <option key={doc._id} value={doc._id}>
                        {doc.name} - {doc.specialization}
                      </option>
                    ))}
                  </select>

                  <select
                    name="time"
                    value={bookingForm.time}
                    onChange={handleBookingChange}
                  >
                    {availableTimes.map((time, idx) => (
                      <option key={idx} value={time}>
                        {time}
                      </option>
                    ))}
                  </select>
                </div>

                <input
                  type="text"
                  name="department"
                  placeholder="Department"
                  value={bookingForm.department}
                  onChange={handleBookingChange}
                />

                <textarea
                  rows="4"
                  name="reason"
                  placeholder="Reason for visit"
                  value={bookingForm.reason}
                  onChange={handleBookingChange}
                ></textarea>

                <button className="primary-btn full-btn" type="submit">
                  Confirm Appointment
                </button>

                {bookingMessage && (
                  <div className="inline-message success">{bookingMessage}</div>
                )}
              </form>
            </div>

            <div className="side-panel">
              <div className="glass-card selected-doctor-card">
                <h3>Selected Doctor</h3>
                {selectedDoctor ? (
                  <>
                    <img
                      src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=1000&q=80"
                      alt={selectedDoctor.name}
                      className="selected-doctor-image"
                    />
                    <h4>{selectedDoctor.name}</h4>
                    <p>{selectedDoctor.specialization}</p>
                  </>
                ) : (
                  <p>No doctor selected</p>
                )}
              </div>

              <div className="glass-card recent-card">
                <h3>Recent Appointments</h3>

                {appointments.length === 0 ? (
                  <p className="subtext">No appointments yet.</p>
                ) : (
                  appointments.slice(0, 5).map((item) => (
                    <div className="recent-item" key={item._id}>
                      <strong>{item.patientName || item.patientId?.name || "Patient"}</strong>
                      <span>{item.doctorId?.name || "Doctor"}</span>
                      <span>{item.phone}</span>
                      <span>
                        {item.date} | {item.time}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </section>
        )}

        {activePage === "about" && (
          <section className="about-grid">
            <div className="glass-card">
              <h2>About Our Hospital</h2>
              <p className="about-text">
                MediCare Plus is a digital hospital platform designed to simplify
                patient registration, doctor listing, and appointment scheduling.
                This website is built as a MERN stack project with responsive UI
                and backend-connected functionality.
              </p>
            </div>

            <div className="glass-card">
              <h3>Why Choose Us</h3>
              <div className="feature-list">
                <div>Secure authentication using JWT and bcrypt</div>
                <div>Doctor and appointment management</div>
                <div>Responsive and interactive frontend</div>
                <div>REST API integration with MongoDB</div>
              </div>
            </div>
          </section>
        )}

        {activePage === "contact" && (
          <section className="contact-grid">
            <div className="glass-card">
              <h2>Contact Us</h2>
              <div className="contact-list">
                <p>
                  <Phone size={16} /> +91 98765 43210
                </p>
                <p>
                  <Mail size={16} /> support@medicareplus.com
                </p>
                <p>
                  <Home size={16} /> Anna Nagar, Chennai, Tamil Nadu
                </p>
              </div>
            </div>

            <div className="glass-card">
              <h3>Working Hours</h3>
              <div className="feature-list">
                <div>Monday - Friday: 8:00 AM to 8:00 PM</div>
                <div>Saturday: 9:00 AM to 6:00 PM</div>
                <div>Sunday: Emergency Support</div>
              </div>
              <button className="primary-btn top-space" onClick={() => goTo("appointment")}>
                Book Now
              </button>
            </div>
          </section>
        )}
      </main>

      <footer className="site-footer">
        <p>© 2026 MediCare Plus. All rights reserved.</p>
        <p>Designed for Hospital Appointment and Patient Management</p>
      </footer>
    </div>
  );
}

export default App;